package Soma;

public class Soma {
	public static int soma (){
	        int indice = 12;
	        int soma = 0;
	        int k = 1;
	        while(k < indice) {
	            k++;
	            soma+=k;
	        }
	        return soma;
	 }
}

